# Android NFC read and write example

http://www.codexpedia.com/android/android-nfc-read-and-write-example/
